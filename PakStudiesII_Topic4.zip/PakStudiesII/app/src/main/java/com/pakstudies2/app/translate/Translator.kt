package com.pakstudies2.app.translate

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.setValue
import com.google.android.gms.tasks.Task
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions
import com.pakstudies2.app.data.UserStore
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * English -> Urdu translation with ML Kit.
 * The language model (about 30 MB) is downloaded once; after that translation works offline.
 * Results are cached in memory, so each text is translated only once per app run.
 */
object Translator {
    private val client by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.URDU)
                .build()
        )
    }

    private val cache = HashMap<String, String>()
    private val downloadLock = Mutex()
    private val translateLock = Mutex()
    private var modelReady = false

    // Observable status for the status bar
    var downloading by mutableStateOf(false)
        private set
    var pending by mutableStateOf(0)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    /** Changes on every retry so that failed texts are translated again. */
    var retryTick by mutableStateOf(0)
        private set

    fun cached(text: String): String? = cache[text]

    fun retry() {
        error = null
        retryTick++
    }

    private suspend fun ensureModel(): Boolean {
        if (modelReady) return true
        return downloadLock.withLock {
            if (modelReady) return@withLock true
            downloading = true
            try {
                client.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                modelReady = true
                true
            } catch (e: Exception) {
                error = "Could not download the Urdu model. Check your internet connection."
                false
            } finally {
                downloading = false
            }
        }
    }

    /** Returns the Urdu text, or null when translation failed (see [error]). */
    suspend fun translate(text: String): String? {
        cache[text]?.let { return it }
        pending++
        try {
            if (!ensureModel()) return null
            return translateLock.withLock {
                cache[text] ?: try {
                    client.translate(text).await().also { cache[text] = it }
                } catch (e: Exception) {
                    error = "Translation failed."
                    null
                }
            }
        } finally {
            pending--
        }
    }

    private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { cont ->
        addOnSuccessListener { cont.resume(it) }
        addOnFailureListener { cont.resumeWithException(it) }
    }
}

/**
 * Returns [text] unchanged in English mode. In Urdu mode it returns the ML Kit translation
 * (the English text is shown until the translation is ready).
 */
@Composable
fun tr(text: String): String {
    if (UserStore.language != "ur" || text.isBlank()) return text
    val tick = Translator.retryTick
    val result by produceState<String?>(Translator.cached(text), text, tick) {
        if (value == null) value = Translator.translate(text)
    }
    return result ?: text
}
