# Pak-Studies II

Punjab PMS Paper 8 (Pakistan Studies-II) study app. Kotlin + Jetpack Compose.

## Part 1 (this version)
- Home: sections A / B / C with the full syllabus topic list
- Topic screen: Overview, Headings (Short / Long for every heading and sub-heading), Key Points, Vocabulary (English-Urdu)
- Content is loaded from JSON in `app/src/main/assets/`:
  - `syllabus.json` - section and topic list (`"available": true` once a topic file exists)
  - `topic_<id>.json` - one file per topic (topic_1.json, topic_2.json included)

## Adding a topic
1. Add `app/src/main/assets/topic_<id>.json` (same structure as topic_1.json)
2. Set `"available": true` for that topic id in `syllabus.json`

## Build
Open in Android Studio and run, or `gradle assembleDebug`.
GitHub Actions workflow comes in Part 5.
