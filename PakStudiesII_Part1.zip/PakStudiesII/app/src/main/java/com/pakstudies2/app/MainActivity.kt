package com.pakstudies2.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.pakstudies2.app.ui.HomeScreen
import com.pakstudies2.app.ui.PakStudiesTheme
import com.pakstudies2.app.ui.TopicScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PakStudiesTheme {
                App()
            }
        }
    }
}

@Composable
fun App() {
    // 0 means "no topic open" (topic ids start at 1)
    var openTopicId by rememberSaveable { mutableStateOf(0) }

    BackHandler(enabled = openTopicId != 0) { openTopicId = 0 }

    if (openTopicId == 0) {
        HomeScreen(onOpenTopic = { openTopicId = it })
    } else {
        TopicScreen(topicId = openTopicId, onBack = { openTopicId = 0 })
    }
}
