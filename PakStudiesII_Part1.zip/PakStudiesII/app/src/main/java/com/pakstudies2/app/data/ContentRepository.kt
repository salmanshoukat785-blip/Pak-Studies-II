package com.pakstudies2.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Loads all study content from JSON files in assets.
 *  - syllabus.json  : sections A/B/C and their topic list
 *  - topic_<id>.json: full content of one topic (added as new topics are written)
 */
object ContentRepository {

    private fun readAsset(context: Context, name: String): String =
        context.assets.open(name).bufferedReader(Charsets.UTF_8).use { it.readText() }

    fun loadSections(context: Context): List<Section> {
        val root = JSONObject(readAsset(context, "syllabus.json"))
        val arr = root.getJSONArray("sections")
        return arr.objects().map { s ->
            Section(
                id = s.getString("id"),
                title = s.getString("title"),
                topics = s.getJSONArray("topics").objects().map { t ->
                    TopicRef(
                        id = t.getInt("id"),
                        title = t.getString("title"),
                        available = t.optBoolean("available", false)
                    )
                }
            )
        }
    }

    fun loadTopic(context: Context, id: Int): Topic? {
        return try {
            val o = JSONObject(readAsset(context, "topic_$id.json"))
            Topic(
                id = o.getInt("id"),
                title = o.getString("title"),
                headings = o.getJSONArray("headings").objects().map { h ->
                    Heading(
                        title = h.getString("title"),
                        short = h.getString("short"),
                        long = h.getString("long"),
                        subs = h.getJSONArray("subs").objects().map { s ->
                            SubHeading(
                                s.getString("title"),
                                s.getString("short"),
                                s.getString("long")
                            )
                        }
                    )
                },
                keyPoints = o.getJSONArray("keyPoints").objects().map {
                    KeyPoint(it.getString("term"), it.getString("text"))
                },
                vocab = o.getJSONArray("vocab").objects().map {
                    VocabItem(it.getString("en"), it.getString("ur"))
                },
                mcqs = o.getJSONArray("mcqs").objects().map { q ->
                    Mcq(
                        question = q.getString("q"),
                        options = q.getJSONArray("options").strings(),
                        answer = q.getInt("answer"),
                        explanation = q.getString("explanation")
                    )
                },
                references = o.getJSONArray("references").objects().map {
                    Reference(it.getString("text"), it.optString("url", ""))
                }
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun JSONArray.objects(): List<JSONObject> =
        (0 until length()).map { getJSONObject(it) }

    private fun JSONArray.strings(): List<String> =
        (0 until length()).map { getString(it) }
}
