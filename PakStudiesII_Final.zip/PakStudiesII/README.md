# Pak-Studies II

Punjab PMS Paper 8 (Pakistan Studies-II) study app. Kotlin + Jetpack Compose.

## Parts 1-4
- Home: sections A / B / C with the full syllabus topic list
- Topic screen: Overview, Headings (Short / Long for every heading and sub-heading), Key Points, Vocabulary (English-Urdu)
- Content is loaded from JSON in `app/src/main/assets/`:
  - `syllabus.json` - section and topic list (`"available": true` once a topic file exists)
  - `topic_<id>.json` - one file per topic (topic_1.json, topic_2.json included)

## Adding a topic
1. Add `app/src/main/assets/topic_<id>.json` (same structure as topic_1.json)
2. Set `"available": true` for that topic id in `syllabus.json`

## Build
Open in Android Studio and run, or `gradle assembleDebug`.
GitHub Actions workflow comes in Part 5.

## Part 5
- Bottom menu: Home, My Notes, Bookmarks, Progress, Settings
- My Notes: personal note per heading (tap "Note" inside a heading); stored on the device
- Offline: all study content, progress, bookmarks and notes work without internet.
  Only the first Urdu translation needs internet (ML Kit downloads the language model once).
- APK build: push or upload this project (or a zip of it) to GitHub; `.github/workflows/build-apk.yml`
  builds the debug APK. Download it from Actions > latest run > Artifacts > Pak-Studies-II-apk.
