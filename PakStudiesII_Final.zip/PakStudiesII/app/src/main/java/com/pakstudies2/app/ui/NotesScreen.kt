@file:OptIn(ExperimentalMaterial3Api::class)

package com.pakstudies2.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pakstudies2.app.data.UserStore
import com.pakstudies2.app.translate.s
import com.pakstudies2.app.translate.tr

/** Dialog to write, edit or delete the personal note of one heading. */
@Composable
fun NoteDialog(
    headingTitle: String,
    initial: String,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(s("My Notes"), style = MaterialTheme.typography.titleMedium) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(headingTitle, style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(text); onDismiss() }) { Text(s("Save")) }
        },
        dismissButton = {
            Row2(
                showDelete = initial.isNotEmpty(),
                onDelete = { onSave(""); onDismiss() },
                onCancel = onDismiss
            )
        }
    )
}

@Composable
private fun Row2(showDelete: Boolean, onDelete: () -> Unit, onCancel: () -> Unit) {
    androidx.compose.foundation.layout.Row {
        if (showDelete) {
            TextButton(onClick = onDelete) { Text(s("Delete")) }
        }
        TextButton(onClick = onCancel) { Text(s("Cancel")) }
    }
}

private data class NoteItem(
    val topicId: Int,
    val index: Int,
    val topicTitle: String,
    val heading: String,
    val text: String
)

/** All personal notes, grouped by topic order. Tap a note to edit it. */
@Composable
fun NotesScreen() {
    val topics = rememberAvailableTopics()
    val items = UserStore.notes.mapNotNull { (key, text) ->
        val parts = key.split(":")
        val tid = parts.getOrNull(0)?.toIntOrNull() ?: return@mapNotNull null
        val idx = parts.getOrNull(1)?.toIntOrNull() ?: return@mapNotNull null
        val topic = topics.firstOrNull { it.id == tid } ?: return@mapNotNull null
        val heading = topic.headings.getOrNull(idx) ?: return@mapNotNull null
        NoteItem(tid, idx, topic.title, heading.title, text)
    }.sortedWith(compareBy({ it.topicId }, { it.index }))

    var editing by remember { mutableStateOf<NoteItem?>(null) }

    Scaffold(topBar = { StudyTopBar(s("My Notes"), onBack = null) }) { padding ->
        Column(Modifier.padding(padding)) {
            if (items.isEmpty()) {
                Text(
                    "No notes yet. Open a heading in any topic and tap \"Note\" to write your own note.",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyLarge
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(items, key = { "${it.topicId}:${it.index}" }) { n ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { editing = n },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    tr(n.heading),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    "Topic ${n.topicId}: ${tr(n.topicTitle)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(n.text, style = MaterialTheme.typography.bodyLarge)
                            }
                        }
                    }
                }
            }
        }
    }

    editing?.let { n ->
        NoteDialog(
            headingTitle = tr(n.heading),
            initial = n.text,
            onSave = { UserStore.saveNote(n.topicId, n.index, it) },
            onDismiss = { editing = null }
        )
    }
}
