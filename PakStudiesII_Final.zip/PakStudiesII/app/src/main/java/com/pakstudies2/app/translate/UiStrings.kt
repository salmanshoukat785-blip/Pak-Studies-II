package com.pakstudies2.app.translate

import androidx.compose.runtime.Composable
import com.pakstudies2.app.data.UserStore

/** Fixed app labels in Urdu. Study content is translated by ML Kit instead (see [tr]). */
private val UR = mapOf(
    "Pak-Studies II" to "پاک اسٹڈیز II",
    "Self Test" to "سیلف ٹیسٹ",
    "Random Mix" to "رینڈم مکس",
    "Timeline" to "ٹائم لائن",
    "Bookmarks" to "بک مارکس",
    "Progress" to "پیش رفت",
    "Settings" to "سیٹنگز",
    "Overview" to "جائزہ",
    "Headings" to "عنوانات",
    "Key Points" to "اہم نکات",
    "Vocabulary" to "مشکل الفاظ",
    "MCQs" to "MCQs",
    "Short" to "مختصر",
    "Long" to "تفصیلی",
    "Index" to "فہرست",
    "In brief" to "خلاصہ",
    "Next" to "اگلا",
    "Previous" to "پچھلا",
    "Finish" to "ختم کریں",
    "Try again" to "دوبارہ کوشش کریں",
    "Back" to "واپس",
    "Result" to "نتیجہ",
    "Correct" to "درست",
    "Home Study Dashboard" to "ہوم اسٹڈی ڈیش بورڈ",
    "Reset progress" to "پیش رفت ری سیٹ کریں",
    "Reset everything" to "سب کچھ ری سیٹ کریں",
    "Language" to "زبان",
    "Text size" to "ٹیکسٹ سائز",
    "Reset" to "ری سیٹ",
    "Cancel" to "منسوخ کریں",
    "Retry" to "دوبارہ کوشش",
    "Loading…" to "لوڈ ہو رہا ہے…",
    "Soon" to "جلد آ رہا ہے",
    "Home" to "ہوم",
    "My Notes" to "میرے نوٹس",
    "Note" to "نوٹ",
    "Edit note" to "نوٹ میں ترمیم",
    "Save" to "محفوظ کریں",
    "Delete" to "حذف کریں"
)

/** Label in the current app language. */
@Composable
fun s(en: String): String =
    if (UserStore.language == "ur") UR[en] ?: en else en
