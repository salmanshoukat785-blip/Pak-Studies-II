@file:OptIn(ExperimentalMaterial3Api::class)

package com.pakstudies2.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pakstudies2.app.data.UserStore
import com.pakstudies2.app.translate.s
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    var confirmReset by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { StudyTopBar(s("Settings"), onBack) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            TranslationStatusBar()

            // Language
            Text(s("Language"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = UserStore.language == "en",
                    onClick = { UserStore.updateLanguage("en") },
                    label = { Text("English") }
                )
                FilterChip(
                    selected = UserStore.language == "ur",
                    onClick = { UserStore.updateLanguage("ur") },
                    label = { Text("اردو") }
                )
            }
            Text(
                "Urdu mode translates the notes with ML Kit and switches the layout to right-to-left. " +
                    "The first translation needs internet to download the language model; after that it works offline.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Text size
            Text(s("Text size"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Slider(
                value = UserStore.textScale,
                onValueChange = { UserStore.updateTextScale((it * 20).roundToInt() / 20f) },
                valueRange = 0.8f..1.5f,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "${(UserStore.textScale * 100).roundToInt()}%",
                style = MaterialTheme.typography.bodyMedium
            )
            OutlinedButton(onClick = { UserStore.updateTextScale(1.0f) }) { Text("100%") }

            // Reset
            Text(s("Reset"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            OutlinedButton(onClick = { UserStore.resetProgress() }) { Text(s("Reset progress")) }
            Button(onClick = { confirmReset = true }) { Text(s("Reset everything")) }
            Text(
                "Reset progress clears read headings and Self Test scores. " +
                    "Reset everything also clears bookmarks, the last topic and these settings.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text(s("Reset everything")) },
            text = { Text("Progress, bookmarks and settings will be erased. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { UserStore.resetAll(); confirmReset = false }) {
                    Text(s("Reset"))
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text(s("Cancel")) }
            }
        )
    }
}
