package com.pakstudies2.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Per-user data stored on the device (works offline):
 *  - bookmarks: headings saved by the user, key "topicId:headingIndex"
 *  - read: headings the user has opened, same key format
 *  - scores: best Self Test percentage per topic
 *  - lastTopic: last opened topic for "Continue"
 * Values are Compose state, so screens update automatically.
 */
object UserStore {
    private var prefs: SharedPreferences? = null

    var bookmarks by mutableStateOf<Set<String>>(emptySet())
        private set
    var read by mutableStateOf<Set<String>>(emptySet())
        private set
    var scores by mutableStateOf<Map<Int, Int>>(emptyMap())
        private set
    var lastTopic by mutableStateOf(0)
        private set

    /** Personal notes written by the user, key "topicId:headingIndex" -> text. */
    var notes by mutableStateOf<Map<String, String>>(emptyMap())
        private set

    fun noteFor(topicId: Int, headingIndex: Int): String = notes[key(topicId, headingIndex)].orEmpty()

    /** Saves the note; an empty text deletes it. */
    fun saveNote(topicId: Int, headingIndex: Int, text: String) {
        val k = key(topicId, headingIndex)
        val clean = text.trim()
        val edit = prefs?.edit()
        if (clean.isEmpty()) {
            notes = notes - k
            edit?.remove("note_$k")
        } else {
            notes = notes + (k to clean)
            edit?.putString("note_$k", clean)
        }
        edit?.putStringSet("noteKeys", notes.keys)?.apply()
    }

    /** "en" or "ur". Urdu switches the layout to right-to-left and translates content with ML Kit. */
    var language by mutableStateOf("en")
        private set
    /** Multiplier applied on top of the system font scale. */
    var textScale by mutableStateOf(1.0f)
        private set

    fun updateLanguage(code: String) {
        language = code
        prefs?.edit()?.putString("language", code)?.apply()
    }

    fun updateTextScale(scale: Float) {
        textScale = scale
        prefs?.edit()?.putFloat("textScale", scale)?.apply()
    }

    /** Clears everything: progress, bookmarks, last topic and settings. */
    fun resetAll() {
        bookmarks = emptySet()
        read = emptySet()
        scores = emptyMap()
        notes = emptyMap()
        lastTopic = 0
        language = "en"
        textScale = 1.0f
        prefs?.edit()?.clear()?.apply()
    }

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("user_store", Context.MODE_PRIVATE)
        prefs = p
        notes = p.getStringSet("noteKeys", emptySet()).orEmpty()
            .mapNotNull { k -> p.getString("note_$k", null)?.let { k to it } }
            .toMap()
        language = p.getString("language", "en") ?: "en"
        textScale = p.getFloat("textScale", 1.0f)
        bookmarks = p.getStringSet("bookmarks", emptySet()).orEmpty().toSet()
        read = p.getStringSet("read", emptySet()).orEmpty().toSet()
        lastTopic = p.getInt("lastTopic", 0)
        scores = p.getString("scores", "").orEmpty()
            .split(",")
            .mapNotNull { item ->
                val parts = item.split(":")
                if (parts.size == 2) {
                    val id = parts[0].toIntOrNull()
                    val pct = parts[1].toIntOrNull()
                    if (id != null && pct != null) id to pct else null
                } else null
            }.toMap()
    }

    fun key(topicId: Int, headingIndex: Int) = "$topicId:$headingIndex"

    fun isBookmarked(topicId: Int, headingIndex: Int) = key(topicId, headingIndex) in bookmarks

    fun toggleBookmark(topicId: Int, headingIndex: Int) {
        val k = key(topicId, headingIndex)
        bookmarks = if (k in bookmarks) bookmarks - k else bookmarks + k
        prefs?.edit()?.putStringSet("bookmarks", bookmarks)?.apply()
    }

    fun markRead(topicId: Int, headingIndex: Int) {
        val k = key(topicId, headingIndex)
        if (k in read) return
        read = read + k
        prefs?.edit()?.putStringSet("read", read)?.apply()
    }

    fun readCount(topicId: Int): Int = read.count { it.startsWith("$topicId:") }

    fun updateLastTopic(topicId: Int) {
        if (topicId == lastTopic) return
        lastTopic = topicId
        prefs?.edit()?.putInt("lastTopic", topicId)?.apply()
    }

    /** Keeps the best percentage for the topic. */
    fun saveScore(topicId: Int, percent: Int) {
        if (topicId <= 0) return
        val old = scores[topicId] ?: -1
        if (percent <= old) return
        scores = scores + (topicId to percent)
        prefs?.edit()?.putString("scores", scores.entries.joinToString(",") { "${it.key}:${it.value}" })?.apply()
    }

    fun resetProgress() {
        read = emptySet()
        scores = emptyMap()
        prefs?.edit()?.remove("read")?.remove("scores")?.apply()
    }
}
