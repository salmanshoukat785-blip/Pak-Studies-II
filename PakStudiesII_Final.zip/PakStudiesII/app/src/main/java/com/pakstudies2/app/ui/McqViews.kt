package com.pakstudies2.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pakstudies2.app.data.Mcq
import com.pakstudies2.app.translate.tr

private val CorrectBg = Color(0xFFD7EFE1)
private val WrongBg = Color(0xFFF8D7D7)
private val CorrectText = Color(0xFF0B5D3B)
private val WrongText = Color(0xFFB3261E)

/**
 * One MCQ. [selected] is the chosen option index or -1.
 * When [reveal] is true the correct/wrong colours and the explanation are shown once an option is chosen.
 */
@Composable
fun McqCard(
    number: Int,
    mcq: Mcq,
    selected: Int,
    reveal: Boolean,
    onSelect: (Int) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                "$number. ${tr(mcq.question)}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(8.dp))
            mcq.options.forEachIndexed { i, option ->
                val bg = when {
                    reveal && selected != -1 && i == mcq.answer -> CorrectBg
                    reveal && selected == i && i != mcq.answer -> WrongBg
                    selected == i -> MaterialTheme.colorScheme.primaryContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(bg)
                        .clickable(enabled = !reveal || selected == -1) { onSelect(i) }
                        .padding(10.dp)
                ) {
                    Text("${'A' + i}.  ${tr(option)}", style = MaterialTheme.typography.bodyLarge)
                }
            }
            if (reveal && selected != -1) {
                Spacer(Modifier.height(6.dp))
                val correct = selected == mcq.answer
                Text(
                    if (correct) "Correct" else "Incorrect. Correct answer: ${'A' + mcq.answer}",
                    fontWeight = FontWeight.Bold,
                    color = if (correct) CorrectText else WrongText
                )
                Text(tr(mcq.explanation), style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
